<?php 
// replace *** with your database credentials
$host="localhost:3307";
$user="root";
$project="db_project";
$ps="";
?>
