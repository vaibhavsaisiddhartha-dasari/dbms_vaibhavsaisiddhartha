<style>
    .foot{
        position: fixed;
        left: 0;
        bottom: 0;
        height: 3vh;
        width:100%;
        color:#042A38;
        background-color:#fff;
        font-weight:bolder;
        margin:0;
        margin-top: 1vh;
    }
</style>
<div class="foot">
    <center>&copy; 2024 kalyanram Poonamalli, Inc. All rights reserved.</center>
</div>